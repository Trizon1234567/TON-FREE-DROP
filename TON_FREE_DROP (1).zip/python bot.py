import logging
from aiogram import Bot, Dispatcher, types
from aiogram.types import Message
from aiogram.filters import CommandStart
from aiogram.enums import ParseMode
import asyncio

# ✅ Your bot token
BOT_TOKEN = "8015314351:AAFWOfM3zjzoi4h1LVjHVmwGo289dIZwFH0"
ADMIN_ID = 7988595664

# Set up logging
logging.basicConfig(level=logging.INFO)

# Initialize bot and dispatcher
bot = Bot(token=BOT_TOKEN, parse_mode=ParseMode.HTML)
dp = Dispatcher()

# /start handler
@dp.message(CommandStart())
async def start_handler(message: Message):
    await message.answer(
        f"👋 Welcome {message.from_user.first_name}!\n\n"
        f"This is your TON Airdrop bot.\n"
        f"You'll receive 1 TON as joining bonus.\n"
        f"Use your referral link to earn more!"
    )

# Echo handler (for testing)
@dp.message()
async def echo_handler(message: Message):
    await message.answer("Please use /start to begin.")

# Main function to start polling
async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
